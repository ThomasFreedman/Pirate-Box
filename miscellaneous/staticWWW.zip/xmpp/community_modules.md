---
title: Community modules
abstract: Community and experimental modules that not distributed as part of Prosody
---

We have a repository for community and experimental modules that are not
distributed as part of Prosody.

If you are a developer and would like to host your Prosody module in
this repository, or want to contribute to existing modules, simply
introduce yourself and request commit access on our [mailing
list](/discuss).

# Notes for users {#notes_for_users}

There are lots of fun and exciting modules to be found here, we know
you\'ll like it. However please note that each module is in a different
state of development. Some are proof-of-concept, others are quite stable
and ready for production use. Be sure to read the documentation page of
any module before installing it on your server.

Installation instructions can be found at [installing community
modules](/doc/installing_modules#prosody-modules). You can also browse
the available modules at
[modules.prosody.im](http://modules.prosody.im/).

# Guidelines for developers {#guidelines_for_developers}

-   Each module should be contained in a folder of its name (e.g.
    mod\_ping/mod\_ping.lua)
-   Each module should have a `README.markdown` file in their folder
    with a description, usage, configuration and todo sections (feel
    free to copy an existing one as a template)
-   Commit messages should begin with the name of the plugin they are
    for (e.g. \"mod\_ping: Set correct namespace on pongs\")

# Google Code migration {#google_code_migration}

In August 2015, the source code repository for these modules moved from
Google Code to our own site,
[modules.prosody.im](http://modules.prosody.im).

If you have previously used [Mercurial
(hg)](https://www.mercurial-scm.org/) to pull updates from the old
repository, you will need to change the URL that it pulls from.

## Updating Mercurial\'s repository URL {#updating_mercurial_s_repository_url}

First, change directory to where your prosody-modules are stored. This
could be anywhere (you can check your Prosody configuration\'s
`plugin_paths` option if you\'re unsure). Here we\'ll assume they are in
`/usr/local/lib/prosody-modules`:

``` {.code .bash}
cd /usr/local/lib/prosody-modules
```

Then edit the file \'.hg/hgrc\' with your preferred editor, e.g. nano:

``` {.code .bash}
nano .hg/hgrc
```

The file you see will look something like this:

``` {.code .file .ini}
[paths]
default = http://code.google.com/p/prosody-modules/
```

Change the \'default\' URL to <https://hg.prosody.im/prosody-modules/> -
so that it looks like this:

``` {.code .file .ini}
[paths]
default = https://hg.prosody.im/prosody-modules/
```
