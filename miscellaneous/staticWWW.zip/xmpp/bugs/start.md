---
title: Reporting a bug
---

Bug reports are essential to improving Prosody. You may file reports for
crashes, errors, and unexpected or unintuitive behaviour.

You may also request features, by tagging the report as an
\"Enhancement\".

# Bug Tracker {#bug_tracker}

Issues are currently recorded in this [issue
tracker](https://issues.prosody.im/).

Be sure to include in your report any relevant log output or tracebacks.

## Security Issues {#security_issues}

Potential security issues should be emailed directly to
<developers@prosody.im> where they will be handled appropriately.
