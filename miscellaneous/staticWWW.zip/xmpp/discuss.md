---
title: Community and discussion channels
abstract: Various discussion avenues about Prosody
---

We love hearing from our users, here is a list of places you can get in
touch, whether you need help with something or just want to say thanks!

# Chatroom

You can join us in our discussion at
[`prosody@conference.prosody.im`](xmpp:prosody@conference.prosody.im?join),
which you can join with your Jabber client if you have one. See you
there!

[:speech_balloon: Join Prosody
chatroom](//chat.prosody.im/ "Needs JavaScript"){.btn .btn-primary}

Also, hang around if we don\'t answer you instantly, sometimes we are so
busy working away on Prosody that we only look into the room every so
often. [:sunglasses:]{.icon}

# Mailing lists {#mailing_lists}

We have two discussion lists, one for users and one for developers. It
is permissible to subscribe to one (or even both!) of these lists,
should you so wish.

Both lists are currently hosted on [Google
Groups](//groups.google.com/). You don\'t need a Google account to
subscribe, simply click the button below.

**Note:** Your first post to the mailing list may not appear instantly -
to prevent spam we approve your initial message manually. We aim to do
this within 24 hours, though most messages are approved very quickly.

## Support

Mailing list for general discussions and support questions.

[Subscribe to
prosody-users](https://groups.google.com/group/prosody-users/subscribe){.btn
.btn-primary} [View
group](https://groups.google.com/group/prosody-users){.btn .btn-default}

You can also subscribe by sending an email to
<prosody-users+subscribe@googlegroups.com>.

## Development

Mailing list for Prosody development and patch review.

[Subscribe to
prosody-dev](https://groups.google.com/group/prosody-dev/subscribe){.btn
.btn-primary} [View
group](https://groups.google.com/group/prosody-dev){.btn .btn-default}

You can also subscribe by sending an email to
<prosody-dev+subscribe@googlegroups.com>.

## Announcements

We also have a list reserved for announcements from the Prosody team
(e.g. announcements of new releases). This list is low traffic and
read-only.

Note that our other mailing lists also receive announcements, so there
is no need to subscribe to this one if you are already on any of our
other lists.

[Subscribe to
prosody-announce](https://groups.google.com/group/prosody-announce/subscribe){.btn
.btn-primary} [View
group](https://groups.google.com/group/prosody-announce){.btn
.btn-default}

You can also subscribe by sending an email to
<prosody-announce+subscribe@googlegroups.com>.

# Contact us {#contact_us}

If you would like to contact the Prosody team directly, you may email us
at <developers@prosody.im>.
