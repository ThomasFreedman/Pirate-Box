---
title: Chatrooms
keywords:
- muc
- groupchat
- chatroom
---

Setting up chatrooms in Prosody is a straightforward task. In
Jabber/XMPP an entire subdomain is usually dedicated to hosting
chatrooms. For example, if your main server is example.com, chatrooms
would be served at conference.example.com.

Simply add a line to your config:

``` {.code .lua}
    Component "conference.example.com" "muc"
```

Specific configuration options for Prosody\'s MUC (Multi-User Chat)
module can be found on our [mod\_muc](/doc/modules/mod_muc) page.

# DNS

A common question is whether a DNS entry is required for subdomains like
this. The answer depends on whether you want users on other servers to
access the service. Users connected to your Prosody instance do not need
a DNS entry for the subdomain, because Prosody already knows about the
service.

If you want users on other servers to find your chat service, you will
need a DNS entry to point them in the right direction. We have a whole
article on [DNS in XMPP](/doc/dns) to help you set that up.

# Discovery

Clients usually find where chatroom are hosted by asking their
VirtualHost about what services are listed. If the chatroom component is
named as a sub-domain of the VirtualHost, it is automatically made
discoverable. To add components or hosts other than sub-domains, they
can be added with the `disco_items` option,\"see
[mod\_disco](/doc/modules/mod_disco).

# Creating rooms {#creating_rooms}

To create a room simply join it with your client - you will become the
owner of that room and, if your client supports it, can configure the
room and add other owners/admins.

If you want to restrict room creation to server admins defined in the
Prosody config, add the restrict\_room\_creation option:

``` {.code .lua}
    Component "conference.example.com" "muc"
        restrict_room_creation = true
```

You can also set the option to **\"local\"** (quotes included), this
restricts the creation of rooms to users on the main domain only (e.g.
example.com in this case).

# Room configuration {#room_configuration}

If you are the owner of a room (for example if you just created it) then
you can configure the room options via your client, if it supports it.
Usually the configuration dialog is accessed via a menu or a command
(some clients, such as Pidgin and Adium, use `/config`).
