---
title: Writing your own telnet commands
---

An example module that adds a command to the [telnet
console](/doc/console):

``` {.code .lua}
module:set_global();
 
local env = module:shared("/*/admin_telnet/env");
 
env.mycommands = {} -- a table to keep your commands in
 
function env.mycommands:hello()
  return "Hello, World!";
end
```

With this saved in a `mod_my_telnet_command.lua` and
[loaded](/doc/modules_enabled) you should be able to call this command
like so:

``` {.code}
mycommands:hello()
| OK: Hello, World!
```

It is also possible to output additional data and indicate success or
failure:

``` {.code .lua}
function env.mycommands:sayhi(name)
  if name then
    self.session.print("Hi, " .. name);
    return true, "Said hi"; -- Boolean true for success, and a status
  else
    return false, "You didn't tell me your name :("
  end
end
```
