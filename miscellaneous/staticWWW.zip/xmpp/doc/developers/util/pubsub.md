---
abstract: 'Abstract Publish-Subscribe library'
title: 'util.pubsub'
---

`util.pubsub` implements an abstract pubsub service along the lines of
[XEP-0060](http://xmpp.org/extensions/xep-0060.html).

The module itself exposes a single constructor function, `new()`, which
takes table with configuration and returns a service instance.

# Usage

Example usage from a module:

``` {.code .lua}
local st = require "util.stanza";
local pubsub_service = module:depends("pubsub").service;
 
local node_name = "example";
function module.load()
    pubsub_service:create(node_name, true);
end
 
function module.unload()
    pubsub_service:delete(node_name, true);
end
 
module:hook("message/host", function (event)
    local stanza, origin = event.stanza, event.origin;
    local id = "current";
    local item = st.stanza("item", { id = id });
    item:add_child(event.stanza); -- the message
    pubsub_service:publish(node_name, true, id, item);
    origin.send(st.reply(stanza):tag("body"):text("Your message has been published"));
    return true;
end);
```

# Service methods {#service_methods}

The service has bunch of methods:

``` {.code .lua}
service:jids_equal(jid1, jid2)
service:may(node, actor, action)
service:set_affiliation(node, actor, jid, affiliation)
service:add_subscription(node, actor, jid, options)
service:remove_subscription(node, actor, jid)
service:remove_all_subscriptions(actor, jid)
service:get_subscription(node, actor, jid)
service:create(node, actor, options)
service:delete(node, actor)
service:publish(node, actor, id, item)
service:retract(node, actor, id, retract)
service:purge(node, actor, notify)
service:get_items(node, actor, id)
service:get_nodes(actor)
service:get_subscriptions(node, actor, jid)
service:set_node_capabilities(node, actor, capabilities)
service:set_node_config(node, actor, new_config)
```

These mostly correspond to XEP-0060 actions.
