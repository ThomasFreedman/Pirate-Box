---
title: 'util.sql'
---

``` {.lua}
local db = require "util.sql":create_engine({
    driver = "SQLite3",
    database = "./data.sqlite",
});
```

::: {.alert .alert-warning}
This documentation has not yet been written. Try again later or [ask if
we forgot about it](/discuss).
:::
