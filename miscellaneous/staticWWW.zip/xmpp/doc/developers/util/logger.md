---
title: 'util.logger'
abstract: An interface to Prosody\'s logging system
---

Prosody\'s logger library allows you to easily generate log messages, or
catch such messages, possibly according to specified criteria.

Note: Prosody plugins already have a logger initialised for them... see
\"[Developing modules:
Logging](/doc/developers/moduleapi#modulelog_level_message)\".

# Reference

## logger.init(name) {#loggerinit_name}

Returns a log() function for the specified source. *name* may be any
short descriptive string, preferably unique. Commonly it is the name of
your module.

## logger.setwriter(writer) {#loggersetwriter_writer}

Accepts a function which will be used for output of all log messages. A
writer function looks like this:

``` {.code .lua}
function mywriter(source, level, message, ...)
 
end
```
