---
title: 'util.hashes'
abstract: Calculate hashes of input data using MD5, SHA1, SHA256, etc.
---

Provides utility functions for hashing strings according to several
popular algorithms.

The algorithms currently supported are:

-   MD5
-   SHA1
-   SHA2-224
-   SHA2-256
-   SHA2-384
-   SHA2-512
-   PBKDF2 with SHA1
-   PBKDF2 with SHA-256 *trunk only*

# Usage

``` {.code .lua}
   local hashes = require "util.hashes";
```

# Reference

## Hash functions {#hash_functions}

``` {.code .lua}
hashes.md5(string, hex)
hashes.sha1(string, hex)
hashes.sha224(string, hex)
hashes.sha256(string, hex) 
hashes.sha384(string, hex)
hashes.sha512(string, hex)
```

All of the above functions return a hash string according to the chosen
algorithm. By default the raw binary form is returned, most often you
will want to pass `true` as the second parameter to get a nice
hex-encoded string.

## HMAC functions {#hmac_functions}

``` {.code .lua}
hashes.hmac_md5(key, string, hex)
hashes.hmac_sha1(key, string, hex)
hashes.hmac_sha256(key, string, hex)
hashes.hmac_sha512(key, string, hex)
```

All of the above functions return a hash string according to the chosen
algorithm. By default the raw binary form is returned, most often you
will want to pass `true` as the third parameter to get a nice
hex-encoded string.

## PBKDF2

``` {.code .lua}
hashes.scram_Hi_sha1(string, salt, iteration_count)
```

In **trunk** (which will become 0.12) the following functions exists:

```lua
hashes.pbkdf2_hmac_sha1(string, salt, iteration_count)
hashes.pbkdf2_hmac_sha256(string, salt, iteration_count)
```

`scram_Hi_sha1` is the same function as `pbkdf2_hmac_sha1`.

## Secure equality check

``` lua
hashes.equals(s1, s2)
```

This will compare two strings in constant time. Depending on Lua
versions and length of the strings, using the equality operator `==` may
introduce timing side channels. Using this function protects against
that.
