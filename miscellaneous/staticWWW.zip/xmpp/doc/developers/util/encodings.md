---
abstract: 'Encode/decode data using algorithms such as base64, IDNA, stringprep'
title: 'util.encodings'
---

Provides an interface for translating a string into various common
encodings.

Currently provided are: base64, idna, stringprep.

# Usage

``` {.code .lua}
   local encodings = require "util.encodings";
 
   print(encodings.base64.encode("Hello world!")) -- prints "SGVsbG8gd29ybGQh"
 
   -- or individually --
   local base64 = require "util.encodings".base64;
   local idna = require "util.encodings".idna;
   local stringprep = require "util.encodings".stringprep;
```

# Reference

## base64

### encode(string) {#encode_string}

``` {.code}
Returns a base64-encoded equivalent of a string.
```

### decode(string) {#decode_string}

``` {.code}
Returns a decoded equivalent of a base64 string, or nil if the string is invalid base64.
```

## idna

IDNA provides a way to safely convert unicode domain names to an ASCII
equivalent, and back again.

### to\_ascii(string) {#to_ascii_string}

``` {.code}
Returns an ASCII-safe version of a unicode domain name, or nil for an invalid domain.
```

Example:

``` {.code .lua}
   print(encodings.idna.to_ascii("➡.ws"))
 
```

``` {.code}
   xn--hgi.ws
 
```

### to\_unicode(string) {#to_unicode_string}

``` {.code}
Returns the original unicode version of an ASCII IDNA-encoded domain.
```

Example:

``` {.code .lua}
   print(encodings.idna.to_unicode("xn--hgi.ws"))
 
```

``` {.code}
   ➡.ws
 
```

## stringprep

Stringprep defines a way of processing and normalizing strings according
to a set of rules (a profile). Prosody implements 4 profiles:

-   nodeprep (for usernames, the node part of a JID)
-   resourceprep (for resources and MUC nicknames)
-   saslprep (for applying to strings prior to calculating SASL
    challenges)
-   nameprep (for applying to hostnames/domains)

Example:

``` {.code .lua}
   print(encodings.stringprep.nodeprep("HelloWorld"))
 
```

``` {.code}
  helloworld
 
```

All stringprep functions return nil when the input is not a valid string
in that particular profile.

## utf8

[UTF-8](https://en.wikipedia.org/wiki/UTF-8) is the [character encoding
used in XMPP](https://xmpp.org/rfcs/rfc6120.html#xml-encoding). Prosody
has a function for validating that a string is a valid UTF-8 encoded
string, primarily used internally in `util.encodings` before passing
data to the libidn library.

`valid(string)`
:   Returns boolean `true` if the string passed is a valid UTF-8 encoded
    string, `false` otherwise.
