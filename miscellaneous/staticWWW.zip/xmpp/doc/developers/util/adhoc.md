---
abstract: 'Convenience library for writing Ad-hoc commands'
title: 'util.adhoc'
---

::: {.alert .alert-warning}
This documentation has not yet been written. Try again later or [ask if
we forgot about it](/discuss).
:::
