---
title: 'util.datetime'
abstract: Retrieve the current or specified time in various XMPP formats
---

Provides utility functions for retrieving the current or specified time
in the formats specified by
[XEP-0082](http://xmpp.org/extensions/xep-0082.html).

# Using

``` {.code .lua}
   local datetime = require "util.datetime";
```

# Reference

In all cases, t is a Lua time value, as returned by os.time(). On most
systems this is stored as the number of seconds since midnight
1970-01-01.

When t is not specified, the current time is used.

## datetime.date(t) {#datetimedate_t}

Returns the time t (or the current time if t is nil or not given) in the
format given by the \'Date\' profile of XEP-0082.

An example return value is:

``` {.code}
2009-03-29
```

## datetime.datetime(t) {#datetimedatetime_t}

Returns the time t (or the current time if t is nil or not given) in the
format given by the \'DateTime\' profile of XEP-0082.

An example return value is:

``` {.code}
2009-03-29T00:33:50Z
```

## datetime.time(t) {#datetimetime_t}

Returns the time t (or the current time if t is nil or not given) in the
format given by the \'Time\' profile of XEP-0082.

An example return value is:

``` {.code}
14:34:47
```

## datetime.legacy(t)


Returns the time t (or the current time if t is nil or not given) in the
format given by the deprecated [XEP-0091: Legacy Delayed Delivery](https://xmpp.org/extensions/xep-0091.html)

An example return value is:

```
20020910T23:08:25
```

## datetime.parse(s)

Parses the timestamp s from the format given by the \'DateTime\' profile of XEP-0082 and returns it as an integer.

An example:

```lua
datetime.parse("2009-03-29T00:33:50Z") --> 1238286830
```


