---
title: 'util.envload'
abstract: Lua version agnostic library for loading code into an environment
---

This small library abstracts the act of loading a piece of Lua code into
a specific environment table.

# envload(code, source, env) {#envload_code_source_env}

Loads code from the string `code` into the environment `env`. `source`
is a descriptive name used in errors. Returns a function to be called,
or `nil, error`.

# envloadfile(file, env) {#envloadfile_file_env}

Like `envload()`, except the code is read from the file `file`.
