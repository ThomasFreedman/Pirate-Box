---
abstract: 'Utility for calculating XEP-0115: Entity Capabilities hashes'
title: 'util.caps'
---

::: {.alert .alert-warning}
This documentation has not yet been written. Try again later or [ask if
we forgot about it](/discuss).
:::
