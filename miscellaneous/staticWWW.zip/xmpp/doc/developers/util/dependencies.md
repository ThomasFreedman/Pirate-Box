---
abstract: Utility containing Prosodys dependencies
title: 'util.dependencies'
---

This module codifies [Prosodys dependencies](/doc/depends) and is
responsible for checking that they are available and printing some
helpful information about how to install them in case they are not.
