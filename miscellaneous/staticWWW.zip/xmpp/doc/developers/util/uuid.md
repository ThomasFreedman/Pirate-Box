---
title: 'util.uuid'
abstract: Generate unique string identifiers
---

Fairly often in XMPP you will want to generate pseudo-random, unique
identifiers. The uuid library provides this functionality.

# Usage

``` {.code .lua}
   local uuid = require "util.uuid";
 
   print("Your id is:", uuid.generate())
```

# Reference

## uuid.generate() {#uuidgenerate}

Returns an id, in the form of a string, in the UUIDv4 format, using
`/dev/urandom` as the PRNG.
