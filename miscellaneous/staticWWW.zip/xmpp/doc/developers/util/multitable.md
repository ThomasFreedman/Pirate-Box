---
title: 'util.multitable'
abstract: A multitable is a handy tree-like data structure, a table allowing multiple keys
---

Multitables are a tree-like data structure that allows mapping of many
keys to one or more values. Generally if a simpler data structure is
possible, it\'s preferred to use a multitable as a last resort for when
mappings are complicated or searching for values across multiple keys is
needed.

# Reference

## Creating

### multitable.new() {#multitablenew}

Returns a new multitable, `mt`. The underlying data structure can be
accessed at `mt.data`.

## Getting and setting {#getting_and_setting}

### mt:get(key1, key2\...) {#mtget_key1_key2}

Returns the value(s) at the specified path (key1→key2→...). Specifying
an incomplete path will return a table with the next possible keys as
keys, and their values as values.

### mt:set(key1, key2\..., value) {#mtset_key1_key2_value}

Sets a value at the specified path.

### mt:add(key1, key2\..., value {#mtadd_key1_key2_value}

Assumes that the value at the given path is an array, and adds `value`
to that array.

## Removing

### mt:remove(key1, key2\...) {#mtremove_key1_key2}

Removes the value at a given path. If an incomplete path is given,
removes all descendents of the last key.

## Searching

### mt:search(key1, key2\...) {#mtsearch_key1_key2}

Searches for values at the given path, matching values are returned in
an array. If any key is given as nil then all keys are matched at that
level.

### mt:search(results, key1, key2\...) {#mtsearch_results_key1_key2}

Same as mt:search() except that matches are appended to the `results`
array. Returns `results`.
