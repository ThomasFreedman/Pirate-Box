---
abstract: 'Perform bit-wise operations on strings'
title: util.strbitop
---

Library for performing efficient bitwise operations on strings.

``` {.lua}
local strbitop = require "util.strbitop";

print(strbitop.sxor("`\160\180&G\233\248\029G\183\180.\t", "(\197\216J"));
-- Prints "Hello, World!"
```

Provided functions are:

-   `sand(s, k)`
-   `sor(s, k)`
-   `sxor(s, k)`

All three take two strings, combines them using bit-wise AND, OR or XOR
and returns the resulting string. If the strings are of unequal length
then the second argument is truncated or repeated to match the length of
the first string.
