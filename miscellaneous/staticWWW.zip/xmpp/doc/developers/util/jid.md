---
title: 'util.jid'
abstract: Common functions for splitting and prepping JIDs
---

Prosody provides an API for manipulating JIDs in various ways.

# Using

``` {.code .lua}
   local jid = require "util.jid";
```

# Reference

## jid.split(id) {#jidsplit_id}

Returns 3 strings, the node, host and resource. The node and/or resource
may be nil (in the case of a bare or domain JID). The host will be nil
only for invalid JIDs (in which case all returns will also be nil).

## jid.prepped\_split(id) {#jidprepped_split_id}

Same as jid.split(id), but runs stringprep over the JID before
splitting.

## jid.prep(id) {#jidprep_id}

Returns the passed JID, after applying the stringprep rules.

## jid.bare(id) {#jidbare_id}

Returns the bare JID, that is the JID without any resource (if it had
one).

## jid.node(id) {#jidnode_id}

Return the node part of a JID. For example,
`jid.node("user@example.com/abc123")` would return `"user"`.

Returns `nil` if the JID has no node part, is malformed, or is nil.

## jid.host(id) {#jidhost_id}

Return the host part of a JID. For example,
`jid.host("user@example.com/abc123")` would return `"example.com"`.

Returns `nil` if the JID is malformed or nil.

## jid.resource(id) {#jidresource_id}

Return the resource part of a JID. For example,
`jid.resource("user@example.com/abc123")` would return `"abc123"`.

Returns `nil` if the JID has no resource, is malformed, or is nil.
