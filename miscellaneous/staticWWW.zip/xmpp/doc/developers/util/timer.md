---
title: 'util.timer'
abstract: Set callbacks to be called after a specified delay
---

Prosody provides a system for setting tasks (functions) to run at
specified times in the future.

# Usage

``` {.code .lua}
   local timer = require "util.timer";
 
   timer.add_task(60, function () log("debug", "Hello!") end);
   -- We can now continue, and in 60 seconds from now, the log message "Hello!" will be printed
```

# Reference

## timer.add\_task(delay, function) {#timeradd_task_delay_function}

Schedules a function to be called after the specified delay, in seconds.

Note that at the time of writing (Prosody 0.4) timers have an accuracy
of +/- 1 second.

# Repeating timers {#repeating_timers}

If you want to make a repeating timer then you can simply return a
number of seconds until you next want the timer to fire.

For the simplest case, if you \"return 60\" from your callback then the
timer will fire again in another 60 seconds.
