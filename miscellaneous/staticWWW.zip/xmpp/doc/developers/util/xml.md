---
abstract: Simple XML parsing library
title: util.xml
---

This library provides a simple way to parse a piece of XML.

It has a single `parse` function, used as such:

``` {.lua}
local xml = require "util.xml";

local doc = xml.parse[[
<document>
  <text>Hello</text>
</document>
]]

print(doc.name) --> "document"
print(doc:get_child_text("text")) --> "Hello"
```
