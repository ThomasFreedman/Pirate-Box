---
abstract: A POSIX library
title: 'util.pposix'
---

POSIX support library

# daemonize

`pposix.daemonize()` forks the process to the background.

Also closes `stdin`, `stdout` and `stderr` and opens `/dev/null` three
times to prevent accidentally reusing the first three file descriptors.

# Syslog

For logging to syslog.

  Function                                  Description
  ----------------------------------------- --------------------------
  `syslog_open(name, facility)`             Connect to syslog
  `syslog_log(level, [section,] message)`   Send a message to syslog
  `syslog_setminlevel(level)`               Set minimum log level
  `syslog_close()`                          Close syslog connection

# process/user id {#processuser_id}

Return or set some numbers associated with a process. These are thin
wrappers around POSIX / C funcitions of the same names.

  Function          Description
  ----------------- -------------------------------------------------
  `getpid()`        Get process id.
  `getuid()`        Get user id.
  `getgid()`        Get group id
  `setuid(uid)`     Change to a different user (must be root)
  `setgid(uid)`     Change to a different group (must be root)
  `initgroups(?)`   Initialize additional groups when changing user

`facility` are strings such as `auth`, `daemon`, `mail` etc to be used
by the syslog daemon for routing to the correct log file.

`level` is one of `debug`, `info`, `notice`, `warn`, `error`.

# umask

Set `umask`, which determines what permissions newly created files get.

# mkdir

Create a directory.

``` {.code}
pposix.mkdir("/some/dir");
```

# getrlimit, setrlimit {#getrlimit_setrlimit}

Get or modify limits applied to the calling process, similar to the
user space `ulimit` tool. Each \"resource\" have two different limits,
one \"soft\" or active limit and one \"hard\" limit. The \"hard\" limit
determines the maximum value that the application can set the limit to,
and as such can only be decreased.

`pposix.getlimit(resource)` if successful returns a boolean true and two
numbers. The first being the current \"soft\" limit for the resource
queried, the second being the \"hard\" maximum that the limit can be
increased to.

`pposix.setrlimit(resource, limit, hard_limit)` attempts to change the
\"soft\" and \"hard\" limits to the value given as second and third
argument.

# uname

Returns a table with information about the kernel and machine, similar
to the user space `uname` tool.

Example:

``` {.code .lua}
uname = {
    ["version"] = "#135-Ubuntu SMP Tue Nov 10 13:33:29 UTC 2015";
    ["domainname"] = "example.com";
    ["release"] = "3.2.0-95-generic";
    ["machine"] = "x86_64";
    ["nodename"] = "server";
    ["sysname"] = "Linux";
}
```

# setenv

`pposix.setenv(name, value)` sets environment variables. Lua itself
provides `os.getenv(name)` for reading.

# meminfo

`pposix.meminfo()` returns a table with information from the memory
allocator `malloc`.

  field             description
  ----------------- ----------------------------------------------------------------------------------------------
  allocated         This is the total size of memory allocated with sbrk by malloc, in bytes.
  allocated\_mmap   This is the total size of memory allocated with mmap, in bytes.
  used              This is the total size of memory occupied by chunks handed out by malloc.
  unused            This is the total size of memory occupied by free (not in use) chunks.
  returnable        This is the size of the top-most releasable chunk that normally borders the end of the heap.

# fallocate

`pposix.fallocate(file, offset, length)` requests that some space on the
disk is allocated to a file handle. If `fallocate()` succeeds, a
subsequent write of at most `length` bytes to the file should not fail.

# abort

Cause an abnormal program termination with core-dump.

# isatty

Answers the question of whether some file handle is a terminal device.
Handy to determine whether it's okay to use ANSI escapes such as colors
and other.

``` lua
if pposix.isatty(io.stdout) then
    local tc = require "util.termcolours";
    print(tc.getstring(tc.getstyle("blue"), "hello"));
else
    print("hello");
end
```
