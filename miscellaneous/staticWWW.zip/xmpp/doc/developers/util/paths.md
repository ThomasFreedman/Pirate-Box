---
abstract: File system path handling
title: util.paths
---

`util.paths` provides some cross-platform operations on file system
paths.

# API

## resolve\_relative\_path

Given a base (parent) path and a relative path, returns an absolute
path.

``` {.lua}
parent_path = "/var/lib/prosody"
path = "example.com"
print(paths.resolve_relative_path(parent_path, path))
--> "/var/lib/prosody/example.com"

print(paths.resolve_relative_path(parent_path, "../foo"))
--> "/var/lib/foo"
```

## glob\_to\_pattern

Turns a glob (e.g. `"*.foo"`) into a [Lua
pattern](//www.lua.org/manual/5.2/manual.html#6.4.1) for use in matching
file names.

``` {.lua}
print(paths.glob_to_pattern("*.foo"))
--> "^.*%.foo$"
```

## join

Joins a number of path components using the system path separator.

``` {.lua}
print(paths.join("path", "to", "something"))
--> "path/to/something"
```
