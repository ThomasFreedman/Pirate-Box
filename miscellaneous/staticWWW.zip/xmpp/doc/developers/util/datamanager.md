---
title: 'util.datamanager'
abstract: Allows persistent storage and retrieval of data
---

Prosody\'s storage system is used via the datamanager library. It allows
the storage of any Lua table, though certain types cannot be saved and
will be dropped from the saved data with a warning logged. For more
information on supported types, see the
[util.serialization](/doc/developers/util/serialization) library
documentation.

# Deprecation warning {#deprecation_warning}

::: {.alert .alert-warning}
[:warning:]{.icon} Note that this API is not recommended for new
modules, and may be removed in a future release. To store and retrieve
data, use the [module storage API](/doc/developers/moduleapi#storage).
:::

# Reference

## load(username, host, datastore) {#load_username_host_datastore}

Returns the data table which is stored in the specified datastore for
the specified user on the specified host.

## store(username, host, datastore, data) {#store_username_host_datastore_data}

Saves the table \'data\' to the given user\'s datastore.

# Examples

Let\'s imagine a module which has a list of JIDs a user wants to be
blocked. The module stores these in a datastore called \"blocks\", for
each user. The user in this example has the JID alice\@localhost.

``` {.code .lua}
   local datamanager = require "util.datamanager"
 
   -- Blocked JIDs for alice@localhost
   local blocked_jids = { "badbob@example.net", "spammer@example.com" }
 
   -- Save them in the user's "blocks" datastore
   datamanager.store("alice", "localhost", "blocks", blocked_jids);
```

Ok, and when we want to retrieve the list of blocked JIDs again:

``` {.code .lua}
   blocked_jids = datamanager.load("alice", "localhost", "blocks")
```
