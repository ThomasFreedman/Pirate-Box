---
title: 'util.http'
abstract: Common functions for dealing with HTTP requests
---

Prosody provides an API for handling HTTP requests in URL or body.

# Using

``` {.code .lua}
   local http = require "util.http";
```

# Reference

## http.urlencode(s) {#urlencode}

Returns a percent-encoding version of the `s` string.

Any character outside of alphanumeric, hyphen (`'-'`), underscore
(`'_'`), dot (`'.'`) and tilde (`'~'`) will be converted to their
hexadecimal UTF-8 representation, with each byte prefixed with a
percent character (`'%'`).

## http.urldecode(s) {#urldecode}

Performs the opposite operation as [urlencode()](#urlencode), returns
the decoded version of a percent-encoded string.

Each sequence starting with a percent character (`'%'`) and followed
with two hexadecimal numbers will be replaced with the byte it
represents.

## http.formencode(query) {#formencode}

Encodes a table into a query string.  The `query` argument can be
either an unordered map of the form `{ key = "value" }`, or an ordered
array of the form `{ { name = "key", value = "value"} }`.

See [Wikipedia](https://en.wikipedia.org/wiki/Query_string) for more
details on query strings.

## http.formdecode(query) {#formdecode}

Decodes a query string into a table and returns it.  The table can be
indexed as normal, and also contains a `{ name = "key", value = "value"
}` sequence for iterating in the order the parameters were passed as.

Fields must be separated by the character `'&'`, and each field must be
of the form `key=value`.

See [Wikipedia](https://en.wikipedia.org/wiki/Query_string) for more
details on query strings.

## http.contains\_token(field, token) {#contains_token}

Returns `true` if token is present in `field`, where `field` is a
comma-separated string.

## http.normalize\_path(path, is\_dir) {#normalize_path}

Makes `path` an absolute path, and append `'/'` if `is_dir` is `true`.
