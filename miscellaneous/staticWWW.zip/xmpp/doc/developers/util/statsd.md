---
abstract: OpenMetrics-compatible core.statsmanager backend
title: 'util.statsd'
---

This module allows you to push various metrics from inside the Prosody process
to a StatsD-compatible backend.

This module also serves as a reference implementation for a push-based
[`core.statsmanager`](/doc/developers/core/statsmanager) *Statistics Backend*.
For general information on statistics backends (such as their API) as well as
a pull-based/perodic reference implementation, see
[`util.statistics`](/doc/developers/util/statistics).

# Creating a StatsD Backend

``` {.lua}
local backend = require \"util.statsd\".new(config);
```

`config` must be a table with the following keys:

- `statsd_server` (required): IP address of the statsd server to push metrics
  to. If a hostname is given, that hostname is resolved once at server startup
  and the IP address is used from then on.
- `statsd_port` (optional): UDP port number to reach statsd at, defaults to
  8125.

Metrics are pushed to the statsd server immediately, unless the output is
[corked](/doc/developers/util/statistics#cork). When corked, updates to gauges
(and only to gauges) are buffered in-memory until the output is uncorked.
This allows to use gauges as aggregators during the periodic collection
without causing a packet storm at the statsd server.
