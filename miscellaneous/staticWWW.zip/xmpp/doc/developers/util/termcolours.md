---
abstract: Library for producing ANSI colour codes
title: 'util.termcolours'
---

Utility for producing colourful terminal output. Mainly used for console
logging. Limited Windows support.

# List of styles {#list_of_styles}

# getstyle

`getstyle` takes a list of colour names or styles and returns the codes
for later use with other functions.

# getstring

Takes a colour code from `getstyle` and some text returns a string with
the appropriate ANSI escape codes so that it gets coloured when printed.
It also adds the reset escape code so that following output are shown as
normal.

# setstyle

Takes a colour code from `getstyle` and writes it to standard output, so
that later output uses this code. Be sure to use the \"reset\" style to
revert back to the default colours.

# tohtml

Turns coloured from `getstring` text into HTML.

# Examples

``` {.code .lua}
local color = require "util.termcolours";
 
local ok = color.getstyle("green");
local warn = color.getstyle("bold", "yellow");
local err = color.getstyle("bold", "red");
local crit = color.getstyle("bold", "bright", "yellow", "red background");
 
print(color.getstring(ok, "Everything is going fine"));
print(color.getstring(warn, "Hm, that's weird..."));
print(color.getstring(err, "Everything is on fire!"));
print(color.getstring(crit, "Take cover, it's gonna blow!"));
print(c--+++CARRIER LOST
```
