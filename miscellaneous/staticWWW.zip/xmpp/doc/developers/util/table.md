---
abstract: 'Small library to complement Luas built-in table module'
title: 'util.table'
---

This library includes a few table related functions.

# create(narr, nrec) {#create_narr_nrec}

Direct interface to the Lua API function
[lua\_createtable](http://www.lua.org/manual/5.1/manual.html#lua_createtable),
which allows specifying how large a table to allocate.

# pack(\...) {#pack}

Packs all arguments into a sequence table along with the field `n` set
to the number of items. Basically the reverse of the
[unpack](http://www.lua.org/manual/5.1/manual.html#pdf-unpack) function
from the Lua standard library and identical to the
[table.pack](http://www.lua.org/manual/5.2/manual.html#pdf-table.pack)
function introduced in Lua 5.2.
