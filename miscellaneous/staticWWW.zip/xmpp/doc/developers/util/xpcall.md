---
abstract: Compat library providing protected Lua function calls with
  error handler
title: util.xpcall
---

The Lua function `xpcall` calls a function in protected mode with a
custom error handler. However, it differs in behavior across Lua
versions. In Lua 5.1, it does not take additional arguments to the
function, while in later versions it does. This library provides a
consistent verison of it.

``` {.lua}
local xpcall = require "util.xpcall".xpcall;

local function onerror(error)
    print("error:", error)
end

xpcall(something_fragile, onerror, arguments);
```
