---
title: 'util.net'
abstract: Common functions for dealing with IP addresses
---

Prosody provides an API for handling IP addresses.

# Using

``` {.code .lua}
   local net = require "util.net";
```

# Reference

## net.local\_addresses(type, link\_local) {#local_addresses}

Returns a table of the available local addresses.

The `type` parameter can be either `"ipv4"`, `"ipv6"` or `"both"`, and
defaults to `"both"` if not provided.

The `link_local` boolean parameter additionally returns addresses
specific to the local area, which won’t be routed globally.

Example:
``` {.code .lua}
   > for _, ip in ipairs(net.local_addresses()) do
   >> print(ip);
   >> end
   192.168.0.1
   2001:db8::1

   > for _, ip in ipairs(net.local_addresses("ipv6", true)) do
   >> print(ip);
   >> end
   2001:db8::1
   fe80::1
```

## net.pton(address) {#pton}

Converts an IP address from its string representation to the network-
order byte representation.

For instance `"127.0.0.1"` will return `"\x7f\x00\x00\x01"`.

## net.ntop(address) {#ntop}

Converts an IP address from its network-order byte representation to
the string representation.

For instance `"\x7f\x00\x00\x01"` will return `"127.0.0.1"`.
