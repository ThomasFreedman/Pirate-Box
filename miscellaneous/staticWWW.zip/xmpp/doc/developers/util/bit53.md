---
abstract: Compatibility module for bitwise operations (Lua 5.3+)
title: util.bit53
---

`util.bit53` is a compatibility library for Lua 5.3 and later where
bitwise operations are operators and may no longer be available as
functions.

This is not used directly but via
[util.bitcompat](/doc/developers/util/bitcompat).

Currently it provides the bitwise operations AND, OR and XOR as
`band()`, `bor()` and `bxor()` respective. At the time of writing these
were the only ones used by Prosody, specifically in the WebSocket code.
