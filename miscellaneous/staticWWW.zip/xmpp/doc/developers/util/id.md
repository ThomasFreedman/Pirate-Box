---
abstract: Generates compact strings suitable for use as identifiers
title: 'util.id'
---

This module provides randomized strings for use as identifiers.
The URL-safe Base64 character set is used.

``` {.lua}
local id = require "util.id"

-- 48 bits of entropy
id.short()  --> aiEerlkh

-- 96 bits of entropy
id.medium() --> 5U-U9kz5cZhdokJI

-- 192 bits of entropy
id.long()   --> N_9lHDBv_PHzPVy2dAasqLSMBMWubaEL

-- variable amount of entropy (n * 8 bits)
id.custom(3) --> function () --> _BJm
```



