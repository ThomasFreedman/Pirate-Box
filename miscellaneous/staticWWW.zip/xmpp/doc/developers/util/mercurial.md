---
abstract: Small library for identifying Mercturial repositories
title: 'util.mercurial'
---

Small utility for figuring out the revision hash and repository id.

``` {.code .lua}
local hg = require "util.mercurial";
 
local commit_id, repository_id = hg.check_id("/usr/src/prosody");
 
print("Repository is on revision "..commit_id);
```
