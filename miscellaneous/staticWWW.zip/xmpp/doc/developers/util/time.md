---
title: 'util.time'
abstract: Low-level time functions
---

Provides low-level high precision timestamps.

# Reference

These all return floating point numbers with sub-second precision.

## time.now()

Returns current wall clock time.

## time.monotonic()

A number guaranteed to always increase monotonically, but unlikely to
have any relation to the current wall-time.
