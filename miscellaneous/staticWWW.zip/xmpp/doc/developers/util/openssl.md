---
abstract: A library for dealing with OpenSSL and certificate configuration
title: 'util.openssl'
---

Utility for dealing with OpenSSLs utilities and configuration format.

# Calling openssl tools {#calling_openssl_tools}

Any of the various OpenSSL command line tools can be called using a
syntax like this:

``` {.code .lua}
local openssl = require "util.openssl";
 
openssl.req({ new = true, out = "key.pem", subj = "/CN=example.com",
        newkey = "rsa:2048", keyout = "my.key" });
```

The above would be equivalent to running the following in a shell:

``` {.code}
openssl req -new -x509 -out key.pem -subj /CN=example.com \
    -newkey rsa:2048 -keyout my.key
```

# Producing a certificate template / config file {#producing_a_certificate_templateconfig_file}

``` {.code .lua}
local openssl = require "util.openssl";
 
local conf = openssl.config.new();
 
if prosody then
    conf:from_prosody(prosody.hosts, config, { "example.com", "conference.example.com" });
else
    conf.distinguished_name.commonName = "example.com";
 
    conf:add_dNSName("example.com");
    conf:add_dNSName("conference.example.com");
 
    conf:add_sRVName("_xmpp-client.example.com");
    conf:add_sRVName("_xmpp-server.example.com");
    conf:add_sRVName("_xmpp-server.conference.example.com");
 
    conf:add_xmppAddr("example.com");
    conf:add_xmppAddr("conference.example.com");
end
 
io.open("cert.cfg", "w"):write(conf:serialize());
```

# Other utilities {#other_utilities}

`openssl.util` contains two functions, `ia5string()` and `utf8string()`
which annotates string for use in config files. This is transparently
used by `conf:add_xmppAddr()` etc.
