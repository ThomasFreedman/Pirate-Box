---
abstract: Compatibility module for bitwise operations
title: util.bitcompat
---

The modules and methods for bitwise operations vary by Lua version, so
this module tries to pick a way to provide the operations Prosody needs.

It may choose one of

-   [bit32](//www.lua.org/manual/5.2/manual.html#6.7) built into Lua 5.2
-   bitops from the LuaJIT project
-   [util.bit53](/doc/developers/util/bitcompat) under Lua 5.3+

Also see the page about Prosodys [dependencies](/doc/depends#bitop).
