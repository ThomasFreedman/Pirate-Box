---
title: 'util.dataforms'
abstract: 'Utility for handling XEP-0004: Data Forms'
---

::: {.alert .alert-warning}
This documentation has not yet been written. Try again later or [ask if
we forgot about it](/discuss).
:::
