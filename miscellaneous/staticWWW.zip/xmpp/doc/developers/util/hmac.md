---
title: util.hmac
---

Provides [keyed hash functions](https://en.wikipedia.org/wiki/HMAC).
This library is actually a front for
[util.hashes](/doc/developers/util/hashes#hash_functions)

``` {.code .lua}
local hmac = require "util.hmac";
hmac.md5(key, string, hex);
hmac.sha1(key, string, hex);
hmac.sha256(key, string, hex);
hmac.sha512(key, string, hex);
```

All of the above functions return a hash string according to the chosen
algorithm. By default the raw binary form is returned, most often you
will want to pass `true` as the third parameter to get a nice
hex-encoded string.
