---
abstract: Produce pseudorandom byte strings
title: util.random
---

This library acts as a common interface to random byte generation.

# Usage

``` {.lua}
local random_bytes = require"util.random".bytes;
local to_hex = require"util.hex".to;

print("Some random data: "..to_hex(random_bytes(8)));
```

# Source

Normally the random data comes from the special device file
`/dev/urandom`. Prosody can optionally be built to use a different
random source, see [`util.crand`](/doc/developers/util/crand).

# API

## bytes(number) {#bytes_number}

The only method. Returns `number` random bytes from some PRNG, usually
`/dev/urandom`.
