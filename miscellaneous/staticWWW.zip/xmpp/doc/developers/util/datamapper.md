% util.datamapper

Given a declarative description of some data, lets you extract that data
from an XML stanza, or turn such data into an XML stanza.

Added in Prosody **trunk**.

# Introduction

As with all utils, to use util.datamapper you have to import it first,
by adding this line near the top of your code:

```lua
local datamapper = require "util.datamapper";
```

Say you have this piece of XML (from [XEP-0092]):

```xml
<query xmlns="jabber:iq:version">
  <name>Prosody</name>
  <version>_LATESTRELEASE</version>
  <os>Linux</os>
</query>
```

Just looking at it, it looks like a record, dict, object (loved child
has many names) with three fields. We can describe it using a variant of
[JSON Schema] with an extension for [XML support][openapixml] from the
[OpenAPI] specification, like this:

[JSON Schema]: https://json-schema.org/
[OpenAPI]: https://www.openapis.org/
[openapixml]: https://spec.openapis.org/oas/v3.1.0#xmlObject

```lua
local = {
    type = "object";
    xml = {
        name = "query";
        namespace = "jabber:iq:version";
    };
    properties = {
        name = "string";
        version = "string";
        os = "string";
    };
};
```

Now you can extract those fields into a convenient table using the
*parse* function.


```lua
data = datamapper.parse(schema, stanza)
```

The `data` variable should now hold a table like this:

```lua
data = {
    name="Prosody";
    version="_LATESTRELEASE";
    os="Linux";
}
```

If you want to turn the data back into XML, you can do that using the
*unparse* function

```lua
stanza = datamapper.unparse(schema, data)
```

Of course, the above could instead have been written like this:

```lua
-- parse-equivalent
data = {
    name = stanza:get_child_text("name");
    version = stanza:get_child_text("version");
    os = stanza:get_child_text("os");
}

-- unparse-equivalent
stanza = st.stanza("query", { xmlns = "jabber:iq:version" })
    :text_tag("name", "Prosody")
    :text_tag("version", "_LATESTRELEASE")
    :text_tag("os", "Linux")
:reset();
```

For such a simple case as this, you probably should, `util.datamapper`
is a pretty big and complex library. But the more complex XML you have
to deal with, the more complicated code it will spare you from writing.
Especially when dealing with deeply nested trees of optional elements,
where you have to check whether each child element really was included
or risk an `attempt to index a nil value` error.

More (and more complicated) examples can be found for example in the
[test cases for `util.datamapper`][spec]

[spec]: //hg.prosody.im/trunk/file/tip/spec/util_datamapper_spec.lua

# Reference

## schema

### Example

```lua
local = {
    type = "object";
    xml = {
        name = "query";
        namespace = "jabber:iq:version";
    };
    properties = {
        name = "string";
        version = "string";
        os = "string";
    };
};
```

This describes an XML stanza (from [XEP-0092]) looking like this:

```xml
<query xmlns="jabber:iq:version">
  <name>Prosody</name>
  <version>_LATESTRELEASE</version>
  <os>Linux</os>
</query>
```

## parse

```lua
data = datamapper.parse(schema, stanza)
-- This might give you a table like:
data = {
    name="Prosody";
    version="_LATESTRELEASE";
    os="Linux";
}
```

## unparse

```lua
stanza = datamapper.unparse(schema, data)
-- would give you back the XML snippet from earlier
```

[XEP-0092]: https://xmpp.org/extensions/xep-0092.html
