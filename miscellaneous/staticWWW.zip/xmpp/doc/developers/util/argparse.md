---
abstract: Parse command line arguments
keywords:
- command line
- cli
- arguments
- parse
title: util.argparse
---

`util.argparse` parses command line arguments and is used by the prosody
and prosodyctl executables.

# Example

``` {.lua}
#!/usr/bin/lua

local argparse = require "util.argparse";

local opts = argparse.parse(arg, { -- 'arg' is set by Lua
    -- -h is the same as --help
    short_params = {
        h = "help";
    };
    -- --user requires a parameter
    value_params = {
        user = true;
    };
});

if opts.help then
    print("example.lua [-h|--help] [--user{=}USER]")
    os.exit(0);
end

print("Hello, "..(opts.user or "World!"))
```
