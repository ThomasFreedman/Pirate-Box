---
abstract: 'Handles loading, un- and reloading of plugins.'
title: 'core.modulemanager'
---

# Loading and unloading

Modulemanager is primarily responsible for handling loading of modules,
setting them up with their environments, API instance and sandbox.

Plugins should normally use
[`module:depends()`](/doc/developers/moduleapi#sharing_code_and_data)
when they need another module to be loaded.

## load(host, module)

Loads a module onto a host and fires a `module-loaded` event on success.

``` {.lua}
local ok, err = modulemanager.load("example.com", "foo");
if ok then
    print("mod_foo was successfully loaded");
else
    print("mod_foo could not be loaded: " .. err);
end
```

## reload(host, module)

## unload(host, module)

## is\_loaded(host, module)

Returns a boolean indicating whether a module is loaded on a host.

``` {.lua}
if modulemanager.is_loaded("example.com", "foobar") then
    print("mod_foobar is loaded!")
end
```

## load\_modules\_for\_host(host)

Calculates all modules to be loaded on a host that has just been
activated. Invoked via a `host-activated` event fired by
[hostmanager](/doc/developers/core/modulemanager).

# Invoking module methods

## call\_module\_method(module, method, ...)

## module\_has\_method()

# Module data

## get\_items(key, host)

# get\_module(host, module)

# get\_modules(host)
