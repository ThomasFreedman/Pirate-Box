---
title: 'core.storagemanager'
abstract: Manages on-demand loading of storage plugins and the storage API
---

`core.storagemanager` manages data the storage layer in Prosody. It's
responsible for loading the configured storage module when a module uses
the [`module:open_store()`](/doc/developers/moduleapi).

# open(host, store, type)

Finds the storage module configured for `store` on `host`, loads it if
needed and calls the storage provider instances `:open()` method with
the `store` and `type` arguments.

# initialize_host(host)

Does initialization of a VirtualHost (or Component). Called during
startup.

# load_driver(host, driver_name)

Returns an instance of storage driver provided by `mod_storage_ + driver_name` on `host`. Loads the storage module if needed.

# get_driver(host, store)

Returns the storage driver for `store` on `host` and the name of the
storage module providing the driver.

# purge(user, host)

Finds every storage module and calls `:purge(user)` on them. Used by
`usermanager` when deleting an user.

# olddm

For compatibility reasons, the
`util.datamanager` module is patched with methods that goes trough
storagemanager, since this was how data storage was used before.

`storagemanager.olddm` is an unaltered instance of `util.datamanager`.
