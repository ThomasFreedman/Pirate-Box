---
abstract: 'Manages server-to-server connections.'
title: 'core.s2smanager'
---

This core module handles creation and dsetruction of server-to-server
connections. Most code dealing with s2s connections
lives in [mod\_s2s](/doc/modules/mod_s2s).

# Sessions

Server-to-server sessions can be found in a few places.

Incoming sessions are kept in a table `incoming_s2s` that is attached to
the `prosody` global and outgoing s2s connections are kept in `s2sout`
on each local host session.

``` {.lua}
prosody.incoming_s2s[session].log("info", "Hello");
prosody.hosts["example.com"].s2sout["federated.example"].log("info", "Hello");
```

# API

The API consists of two functions for creating sessions and two related
to destroying them.

A new session is created with either
`new_outgoing(from_host, to_host)`{.lua} or `new_incoming(conn)`{.lua}
depending on whether the connection was initiated by the local instance
or by a remote server.

`destroy_session(session, reason)`{.lua} destroys a session, which
includes sending error replies for any queued stanzas.

There is also `retire_session()` which cleans up the session prior to
garbage collection, but this is called by `destroy_session()` so it
rarely needs to be used directly.
