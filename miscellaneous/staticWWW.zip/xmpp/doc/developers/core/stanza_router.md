---
abstract: 'Routes stanzas to the right host and fires the correct events.'
title: 'core.stanza\_router'
---

The stanza router handles basic routing of stanzas to the correct host
and fires events that are then handled by modules. It also handles
sending error replies for unhandled stanzas.

# Description

When Prosody receives a stanza from a connected client or remote server,
called an "origin", it enters the routing process via
`prosody.core_process_stanza()`, where some authorization and sanity
checks are performed. If the origin session is not authorized to send
stanzas yet, i.e. because it has not authenticated or bound a resource,
it is rejected here.

Processing then passes to `prosody.core_post_stanza()`, where events are
fired to dispatch the stanza to handling by interested modules. If
modules generate a reply of some sort, that often gets sent directly to
the origin session, bypassing most routing logic.

Stanzas created by Prosody itself, i.e. in modules, enter routing trough
`prosody.core_post_stanza()`. Modules should use the `module:send()` API
which in turn calls `core_post_stanza` behind the scenes.

# API

TL;DR:

``` {.lua}
-- Stanza received from e.g. a connected client
prosody.core_process_stanza(origin, stanza);

-- Fire events for stanza received from a client
prosody.core_post_stanza(origin, stanza, true);

-- Send a stanza out from Prosody
prosody.core_post_stanza(origin, stanza, false);

-- Similar to the above
prosody.core_route_stanza(origin, stanza);
```
