---
abstract: Handles logging configuration
title: 'core.loggingmanager'
---

Loggingmanager handles connecting all the `log()` calls to the
configured log files or other sinks.

# reload\_logging()

Resets the logging system, retrieves current logging configuration from
[loggingmanager](/doc/developers/core/loggingmanager) and initializes
the configured log files or other sinks, eg
[syslog](/doc/modules/mod_posix).

# register\_sink\_type(name, sink\_maker)

`register_sink_type()` lets you provide your own logging sink.
