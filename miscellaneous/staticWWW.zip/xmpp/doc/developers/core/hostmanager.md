---
abstract: 'Manages initialization of virtual hosts.'
title: 'core.hostmanager'
---

Hostmanager handles initialization and tear down of virtual hosts.
During startup, all enabled VirtualHosts and Components from the config
are activated.

# activate(host)

Creates `prosody.hosts[host]` and signals that it has been activated to
other modules such as
[modulemanager](/doc/developers/core/modulemanager).

# deactivate(host)

Closes all client and server connections, unloads all modules and
deactivates the host.

# get\_children(host)

Given eg `example.com`, returns other hosts matching
`subdomain.example.com`.
