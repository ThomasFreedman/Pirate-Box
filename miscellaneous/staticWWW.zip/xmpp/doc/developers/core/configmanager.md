---
abstract: 'Handles reading, parsing and accessing the configuration.'
title: 'core.configmanager'
---

The configuration manager handles parsing the configuration file and
provides access to settings. Normally, only other Prosody internals use
it directly, modules should use the [Module
API](/doc/developers/moduleapi#configuration).

# load(filename, config\_format)

Loads the configuration file `filename`. `config_format` is optional. If
left out, the file extension from `filename` is used. The only supported
value is `"lua"`.

# get(host, key)

Returns the config option with a name given by `key` in the VirtualHost
or Component section given by `host`, or the global section if `host` is
`"*"`. If there is no setting for the given `host` but there is one in
the global section, that value is returned.

# rawget(host, key)

Works like `get()` but does not fall back to global settings if asked
for a setting on a host where it is missing.

# getconfig()

Returns the entire internal config representation in the form of a
table.

# set(host, key, value)

Writes to the in-memory config table.

::: {.alert .alert-info}
Note the distinct lack of a `write()` method, so changed settings are
not persistent.
:::
