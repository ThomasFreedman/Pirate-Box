---
abstract: Handles TLS settings and certificates
title: 'core.certmanager'
---

This core module handles TLS settings and certificates.
[Portmanager](/doc/developers/core/portmanager) and
[mod\_tls](/doc/modules/mod_tls) uses it to provide TLS.

# create\_context()

Creates a LuaSec TLS context. Takes a hostname, the mode (`"client"` or
`"server"`) and an arbitrary number of tables with TLS configuration
settings, which are merged using
[util.sslconfig](/doc/developers/util/sslconfig).

``` {.lua}
local context, err, config = certmanager.create_context("example.com", "server", config);
ssl.wrap(conn, ctx);
```

# reload\_ssl\_config()

Reloads settings from the configuration. Called automatically after the
configuration has been reloaded, so rarely needed.

# find\_cert()

Looks for certificate and private key files for a hostname using a few
common patterns.

``` {.lua}
local conf = certmanager.find_cert("/etc/certs/example/", "example.com")
print(conf.certificate, conf.key)
```
