---
abstract: Handles setting up TCP port listeners
title: 'core.portmanager'
---

# API

Normally used via [Module API](/doc/developers/moduleapi) as such:

``` {.lua}
module:provides("net", {
    listeners = {
        onconnect = function(conn)
        end;
        onincoming = function(conn, data)
        end;
        ondisconnect = function(conn, err)
        end;
    };
    default_port = 9999;
});
```
