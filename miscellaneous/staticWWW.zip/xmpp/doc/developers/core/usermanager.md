---
abstract: Core API for user account management
title: 'core.usermanager'
---

This core module is responsible for managing authentication providers
and user accounts.

# Basic account management

`core.usermanager` provides APIs for adding and removing user accounts,
changing passwords as well as listing existing accounts and testing
whether an account exists. The basics are fairly straight forward:

Create a new user
:   `create_user(username, host)`

Remove user account
:   `delete_user(username, host)`

Account exists?
:   `user_exists(username, host)`

Test password
:   `test_password(username, host, password)`

Get user password ^[Does not work with hashed password storage]
:   `get_password(username, host)`

Updates password
:   `set_password(username, password, host, resource)`

Check admin status
:   `is_admin(jid, host)`

Account iterator
:   `users(host)`

::: {.alert .alert-warning}
Listing accounts on a host with large numbers of users can be a
performance issue and should generally be avoided.
:::

## Example

``` {.lua}
local usermanager = require "core.usermanager"
local host = "example.com";

usermanager.create_user("john.doe", host)
if usermanager.user_exists("unlucky", host) then
    usermanager.delete_user("unlucky", host)
end

for user usermanager.users(host) do
    print(user .. "@" .. host)
end
```

# Authentication interfaces

`get_provider(host)`
:   Returns the selected authentication provider on `host`

`get_sasl_handler(host, session)`
:   Creates a new SASL handler and passes it the `session`

# Other

`initialize_host(host)`
:   called for each enabled `VirtualHost` during startup to initialize
    user handling.

`new_null_provider()`
:   Returns a dummy SASL handler. Used as fallback in case of problems
    loading the configured authentication module.
