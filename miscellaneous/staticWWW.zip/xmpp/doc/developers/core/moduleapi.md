---
abstract: Implements the Module API
title: 'core.moduleapi'
---

[`core.moduleapi`](https://hg.prosody.im/trunk/file/tip/core/moduleapi.lua)
is where all the methods of the `module` object available to plugins are
implemented.

If imported, returns a table with all the methods of the [Module
API](/doc/developers/moduleapi).

``` {.lua}
local api = require "core.moduleapi";
local module = setmetatable({ name = "foobar", },
    { __index = api });
print(module:get_name()) --> prints foobar
```
