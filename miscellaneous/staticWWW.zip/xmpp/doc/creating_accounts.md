---
title: Creating accounts
---

The first thing you will normally want to do after installing Prosody is
to create yourself (and possibly others) accounts, or allow them to
create accounts.

There are multiple ways you can create accounts:

# prosodyctl

Prosody has a command-line utility called [prosodyctl](/doc/prosodyctl). This
can be used to add a user account like so:

``` {.code}
 prosodyctl adduser me@example.com
```

Prosody will then prompt you for a password, and you will be able to log
into your account using your client.

For batch registration of accounts consider the 'prosodyctl register'
command, which allows you to specify everything on one line:

``` {.code}
 prosodyctl register me example.com mypassword
```

# Ad-hoc command

The module [`mod_admin_adhoc`](/doc/modules/mod_admin_adhoc) provides
several commands for administrators, including account creation.

To use this, you need a client that supports [XEP-0050: Ad-Hoc
Commands](https://xmpp.org/extensions/xep-0050.html). This is currently
more common among more fully-featured clients such as Gajim, Swift and
Psi.

Add or uncomment `"admin_adhoc"` in
[modules\_enabled](/doc/modules_enabled) to activate the module.

In your client, look for "Execute server command" or similar option.
Then, to create an account, select "Add User" from the list of commands.
You should be presented with a form with fields for username and
password, fill them in and submit it.

# In-band registration {#in-band_registration}

::: {.alert .alert-warning}
Servers with unrestricted registration are open to abuse and provide an
easy method for spammers to get onto the XMPP network. If you do not
control this, your server may be blocked by other servers on the
network.

If you intend to provide service to anyone who wants to sign, see our
[page with best practices for running a public
server](/doc/public_servers).
:::

In-band registration in Jabber is a way for clients to ask the server to
create an account. Obviously enabling such a protocol on the open
internet can lead your server open to abuse, so in the default
configuration registration is disabled.

To allow registration for a host, make sure mod\_register is loaded
(that you have `"register"` in [modules\_enabled](/doc/modules_enabled))
and add this line:

``` {.code}
  allow_registration = true
```

<!--
TODO Update for module split into mod_register_{ibr,limits}
-->

It is possible to secure account registration a bit by restricting it to
particular IP addresses, or limiting how often an IP address can
register an account. These options are described on our [configuration
page](/doc/configure#registration).

# Importing from ejabberd {#importing_from_ejabberd}

Prosody has a tools to convert ejabberd database dumps to Prosody's own
data format. These tools currently aren't supplied with any packages
(we're working on it) but if you have the Prosody [source
package](/download/start#source_code) then you can do the following:

First, export data from ejabberd using:

``` {.code}
sudo ejabberdctl dump ejabberd_dumpt.txt
```

Then, convert it using `ejabberd2prosody.lua`:

``` {.code}
./tools/ejabberd2prosody.lua ejabberd_dump.txt
```

If you're using ejabberd with a MySQL backend, you may use
ejabberdsql2prosody in the following way

``` {.code}
./tools/ejabberdsql2prosody.lua filename.sql hostname
```

...where filename.sql is a MySQL dump created by e.g. "mysqldump
db\_name \> filename.sql"

