---
title: Components in Prosody
---

Components are extra services on a server which are available to
clients, usually on a subdomain of the main server (such as
mycomponent.example.com). Example components might be chatroom servers,
user directories, or gateways to other protocols.

Prosody supports internal components (implemented with Prosody-specific
plugins) and external components (using XEP-0114, which most standalone
components support).

## DNS

If a component needs to be accessed from remote servers over s2s, you
must have a record for it in DNS (either **A** or *\_xmpp-server.\_tcp*
**SRV** records), see [DNS configuration in Jabber/XMPP](/doc/dns).

## Encryption

You may also want to specify an SSL certificate for s2s connections with
the component if the \'parent\' domain\'s certificate does not cover it.
This is simply achieved by adding an [\'ssl\'
option](/doc/configure#encryption_and_security_settings) under the
Component entry in the config file. If a component is a direct
sub-domain of a virtual host, the component will use that host\'s
certificate by default.

# Adding an internal component {#adding_an_internal_component}

To add a component, you simply add a line to the config file specifying
the hostname, and the plugin you wish to use for the component.

An example of adding the Prosody [MUC](/doc/modules/mod_muc) component
would be:

``` {.code .lua}
Component "conference.jabber.org" "muc"
```

## Adding additional modules to an internal component

Some modules such as [mod_muc_mam](/doc/modules/mod_muc_mam) enable
additional functionality for a Component. These *must not* be enabled in
the global [`modules_enabled`](/doc/modules_enabled), but rather in a
`modules_enabled` under the Component, like so:

``` lua
Component "conference.jabber.org" "muc"
modules_enabled = {
    "muc_mam",
}
```

# Adding an external component {#adding_an_external_component}

Prosody supports all external components that use the XEP-0114 component
protocol (practically all do).

Example external components include [Spectrum](http://spectrum.im/),
which we recommend if you wish to bridge your Prosody server to legacy
IM networks such as MSN, Yahoo, AIM and ICQ. You can use the
documentation on the [Spectrum site](http://spectrum.im/documentation/)
to further assist you.

To add an external component, you need to tell Prosody the address and a
password (or \'secret\') which the component will use to log in. Be sure
that the password and the port (Prosody defaults to 5347) that you tell
Prosody match the same password and port in your component\'s
configuration file(s).

Definition is the same as for internal components, except no internal
plugin is specified:

``` {.code .lua}
Component "msn.example.org"
         component_secret = "mysecretcomponentpassword"
```

To configure the port(s) Prosody listens on for component connections,
set the component\_ports option in the global section of the config. The
default port is 5347. Multiple components can all use the same port to
connect.

Also by default for security Prosody will only listen for connections on
the local interface (127.0.0.1 or 'localhost'). This can optionally be
changed with the global `component_interfaces` option.

For example:

``` {.code .lua}
-- Global config section --
component_ports = { 8888 }
component_interfaces = { "192.168.0.10" }
```

The above would configure Prosody to listen for component connections on
port 8888, coming only to the IP address 192.168.0.10.

XEP-0114 provides no standard for encryption of component connections,
and so connections from external components are not affected by the
\"require\_encryption\" option.
