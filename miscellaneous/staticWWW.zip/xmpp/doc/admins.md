---
title: The admins configuration option
---

There are some features of Prosody which are generally for use only by
the owner of the server, or of a select group of administrators.

Prosody allows you to specify who is an administrator using the `admin`
option in the configuration file.

For example:

``` {.code .lua}
admins = { "me@example.com", "trustedperson1@example.net" }
```

Each host can have a different set of admins (simply put the option into
the correct host's section).
