---
title: Backups
---

Backups are very important, and for any reliable XMPP service Prosody
should be a part of your regular backup routine.

There are two things you should care about primarily: your configuration
and your user data.

On most systems the correct paths will be:

Configuration
:   `/etc/prosody`

Data
:   `/var/lib/prosody`

Both of these directories may already be covered by your system backups
(/etc and /var/lib are both standard directories for configuration and
data files). Remember that the paths may be different on your platform,
depending on how you installed Prosody - so do check. The command
`prosodyctl about` should tell you the correct paths for your
installation.

If you do not use the default storage, e.g. if you use an external
database, don\'t forget to **also** back up that database regularly. We
recommend that Prosody\'s standard data directory should still be a part
of your backup routine in this case.
